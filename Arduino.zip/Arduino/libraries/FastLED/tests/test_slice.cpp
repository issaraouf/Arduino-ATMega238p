
// g++ --std=c++11 test.cpp

#include "test.h"

#include "test.h"
#include "fl/slice.h"

#include "fl/namespace.h"
FASTLED_USING_NAMESPACE

TEST_CASE("compile test") {

}
